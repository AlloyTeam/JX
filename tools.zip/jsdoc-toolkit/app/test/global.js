/** ecks */
var x = [1, 2, 4];

var y = {
	foo: function(){
	}
}

bar = function() {
}

function zop() {
}
