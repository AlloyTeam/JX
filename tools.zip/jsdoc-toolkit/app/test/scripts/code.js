/**
	@class
 */
function thisiscode() {
}